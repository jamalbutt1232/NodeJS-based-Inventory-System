var mongoose = require("mongoose");

var customerCredit = new mongoose.Schema({
    date:Date,
    vendor_name :  String,
    total_credit_amount : Number
});

module.exports= mongoose.model("customerCredit", customerCredit);