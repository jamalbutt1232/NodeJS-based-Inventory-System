var mongoose = require("mongoose");

var vendorPayingHistory = new mongoose.Schema({
    date:Date,
    day : Number,
    month: Number,
    year: Number, 
    vendor_name :  String,
    paying : Number
});

module.exports= mongoose.model("vendorPayingHistory", vendorPayingHistory);