var mongoose = require("mongoose");

var customerPayingHistory = new mongoose.Schema({
    date:Date,
    day : Number,
    month: Number,
    year: Number, 
    customer_name :  String,
    paying : Number
});

module.exports= mongoose.model("customerPayingHistory", customerPayingHistory);