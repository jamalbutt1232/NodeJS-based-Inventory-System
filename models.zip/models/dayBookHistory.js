var mongoose = require("mongoose");

var dayBookHistory = new mongoose.Schema({
    date:Date,
    day : Number,
    month: Number,
    year: Number, 
    total:Number,
});

module.exports= mongoose.model("dayBookHistory", dayBookHistory);