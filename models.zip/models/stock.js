var mongoose = require("mongoose");

var stockSchema = new mongoose.Schema({
    date:Date,
    product_name : String,
    vendor_name :String,
    retail: Number,
    incoming_q:Number,
    incoming_per_item:Number,
    incoming_total:Number,
    remaining_quantity:Number
});

module.exports= mongoose.model("stock", stockSchema);