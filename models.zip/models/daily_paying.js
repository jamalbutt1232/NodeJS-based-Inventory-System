var mongoose = require("mongoose");

var daily_paying = new mongoose.Schema({
    date:Date,
    day : Number,
    month: Number,
    year: Number, 
    expenditure_name:String,
    paying:Number,
 });

module.exports= mongoose.model("daily_paying", daily_paying);