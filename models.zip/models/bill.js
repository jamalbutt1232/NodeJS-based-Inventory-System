var mongoose = require("mongoose");

var bill = new mongoose.Schema({
    date:Date,
    billNo:  Number,
    name :String,
    quantity:Number,
    product:String,
    vendor:String,
    rate:Number,
    amount:Number
   
});

module.exports= mongoose.model("bill", bill);