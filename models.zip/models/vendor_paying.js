var mongoose = require("mongoose");

var vendordebit = new mongoose.Schema({
    date:Date,
    vendor_name :  String,
    total_debit_amount : Number
});

module.exports= mongoose.model("vendordebit", vendordebit);